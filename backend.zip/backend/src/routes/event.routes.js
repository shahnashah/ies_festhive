// src/routes/event.routes.js
import express from "express";
import {
  createEvent,
  updateEvent,
  deleteEvent,
  getAllEvents,
} from "../controllers/event.controller.js";
import { TokenGuard } from "../middleware/auth.middleware.js";
import adminMiddleware from "../middleware/admin.middleware.js";

const router = express.Router();

// Public
router.get("/", getAllEvents);

// Admin Protected Routes
router.post("/create", TokenGuard, adminMiddleware, createEvent);
router.put("/edit/:id", TokenGuard, adminMiddleware, updateEvent);
router.delete("/delete/:id", TokenGuard, adminMiddleware, deleteEvent);

export default router;
