import express from "express";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import {
  adminSignup,
  adminLogin,
  addProduct,
  updateProduct,
  deleteProduct,
  fetchProducts,
  getAllUsers,
  getAllContacts,
} from "../controllers/admin.controller.js";
import adminMiddleware from "../middleware/admin.middleware.js";
import { TokenGuard } from "../middleware/auth.middleware.js";
import Admin from "../model/admin.model.js";



const router = express.Router();

// 🔹 Resolve __dirname in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

//  Admin Routes
router.post("/signup", adminSignup);
router.post("/login", adminLogin);




export default router;
