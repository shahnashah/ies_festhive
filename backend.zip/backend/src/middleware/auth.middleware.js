import jwt from "jsonwebtoken";

import User from "../model/user.model.js";
import Admin from "../model/admin.model.js"; 








export const TokenGuard = async (req, res, next) => {
    try {
        console.log("Full Request Headers:", req.headers);
        console.log("Cookies:", req.cookies);
        
        const token = req.cookies.jwt;

        if (!token) {
            console.log("No token found");
            return res.status(401).json({ error: "Access Denied: No Token Provided" });
        }

        console.log("Token received:", token);
        
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        console.log("Decoded Token:", decoded);

        if (!decoded) {
            console.log("Token could not be decoded");
            return res.status(401).json({ error: "Access Denied: Token Expired or Invalid" });
        }
        
        
        const user = await Admin.findById(decoded.id).select("-password");
        
        if (!user) {
            console.log("User not found for ID:", decoded.id);
            return res.status(404).json({ error: "User Not Found" });
        }

        console.log("User found:", user);
        req.user = user;
        next();
    } catch (error) {
        console.error("Token Verification Error:", error);
        return res.status(401).json({ error: "Invalid or Expired Token", details: error.message });
    }
};












export const userLog = (req, res, next) => {
    console.log(
      `Test Request is executed for user 
      ${req.url} with 
      ${req.method} Method at 
      ${new Date().toISOString()}`
    );
  
    next();

   

}
  
export const confirmUser = async (req, res, next) => {
  try {
    console.log("Cookies:", req.cookies.jwt);
    
    
    const token = req.cookies.jwt;


    

    if (!token) {
        return res.status(401).json({ error: "Access Denied: No Token Provided" });
    }
    console.log("Token Verified");
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!decoded) {
        return res.status(401).json({ error: "Access Denied: Token Expired or Invalid" });
    }
   
    

    const user = await User.findById(decoded.userID).select("-password");
    if (!user) {
        return res.status(404).json({ error: "User Not Found" });
    }

    req.user = user;
    next();
} catch (error) {
    return res.status(401).json({ error: "Invalid or Expired Token" });
}
  };
